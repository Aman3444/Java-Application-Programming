//File name: MVCObserverOservableDemo.java
//  Demonstrates Observer/Observable Design Pattern in Java
//  applied to MVC 
//  Author: Sv. Ranev

import java.util.Observable;
import java.util.Observer;

/** This is the application launcher class*/
public class MVCObserverOservableDemo  {
  MyView view;
  MyController controller;
  MyModel model;

  public MVCObserverOservableDemo() {
    model = new MyModel();
    view = new MyView();
    controller = new MyController(model);
  }

  public static void main(String[] av) {
    MVCObserverOservableDemo mvc = new MVCObserverOservableDemo();
    mvc.model.addObserver(mvc.view);
    mvc.controller.start();
  }
}

 /** This is the controller class*/
 class MyController {
   private MyModel model;


  public MyController (MyModel model){
   this.model = model;
  }
  public void start(){
    model.changeState();
  }
 } 
  /** The Observer class normally maintains a view on the data */
  class MyView implements Observer {
    String modelData;
    
   /** This method is called automatically by the run-time
    *  if an observable changes its state and notifies Observers.
    *  @param o the observable object that sent the notification for state change.
    *  @param arg an argument passed to the notifyObservers method
    */
@Override   
    public void update(Observable o, Object arg) {
      if(arg instanceof String)modelData = (String)arg;
      else modelData = null;
      if(modelData != null) displayModelData();
    }
    /** The View update method */
    public void displayModelData(){
     System.out.println("Model data: " + modelData);
    }
  }

  /** The Observable class normally maintains and manipulates the data */
  class MyModel extends Observable {
    String result;
    /** This method changes the model data (state) */
    public void changeState() {
      result = "Result changed";
      // Notify observers of change
      setChanged();
      notifyObservers(result);
    }
  }


