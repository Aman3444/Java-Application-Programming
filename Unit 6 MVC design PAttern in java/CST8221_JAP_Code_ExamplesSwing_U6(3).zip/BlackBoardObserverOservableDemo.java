//File name: BlackBoardObserverOservableDemo.java
// Demonstrates Observer/Observable Design Pattern 
// implementation in Java
// Author: Sv. Ranev
import java.util.Observable;
import java.util.Observer;

/** This is the application launcher class*/
 public class BlackBoardObserverOservableDemo{
  public static void main(String[] args) {
    BlackBoard board = new BlackBoard();
    Student great =   new Student();
    Student greatest = new Student();
    //this is how you register an Observer
    board.addObserver(great);
    board.addObserver(greatest);
    board.changeMessage("Your marks are posted!");
    board.deleteObserver(great);
    board.changeMessage("You are the best!");
  }
}

/** This is the Observable class. It notifies all interested objects
 *  for changes in it state.
 */
 class BlackBoard extends Observable {
  private String message;
  
  /** Returns the content of the current message
   *  @return the content of the current message  
   */
  public String getMessage() {
    return message;
  }
  /** This is the method that changes the state of the object.
   *  After the state is changed the method notifies all 
   *  interested observing objects.
   *  @param the BB message.
   */
   
  public void changeMessage(String message) {
    super.setChanged();
    this.message = message;
    notifyObservers(message);
  }
 }
/** This is the Observer class. It is notified if the Observable object
 *  changes its state.
 */ 
class Student implements Observer {
  /** This method is called automatically by the run-time
   *  if an observable changes its state and notifies Observers.
   *  @param o the observable object that sent the notification for state change.
   *  @param arg an argument passed to the notifyObservers method
   */
@Override  
   public void update(Observable o, Object arg) {
      System.out.println("Number of Observers: " + o.countObservers()); 
      System.out.println(o.getClass().getCanonicalName() + " notification: " + arg);
    }
}
