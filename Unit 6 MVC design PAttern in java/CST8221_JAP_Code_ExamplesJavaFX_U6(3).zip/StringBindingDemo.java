import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;
/**This program demonstrates binding in Java 8 - JavaFX. Binding implements
   the Observer/Observable Design Pattern.
   There are similar classes for Boolean,Long,Integer, Float, Double.
*/
public class StringBindingDemo {
  public static void main(String[] args) {       
    StringProperty target = new SimpleStringProperty("TARGET");
    StringProperty source = new SimpleStringProperty("SOURCE");
    System.out.println("target is " + target.getValue() 
      + " and source is " + source.getValue());
    target.bind(source);
    System.out.println("target is " + target 
     + " and source is " + source);
    System.out.println("target is " + target.getValue() 
      + " and source is " + source.getValue());
    source.setValue("NEW SOURCE");
    System.out.println("target is " + target.getValue() 
      + " and source is " + source.getValue());
  }
}