import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
/** This program demonstrates the Jvava 8 - JavaFX implementation of Observer/Observable 
    Design Pattern using event handlers.
    Every binding property is an instance of Observable.
*/
public class ObservablePropertyDemo {
  public static void main(String[] args) {
    DoubleProperty observer_observable = new SimpleDoubleProperty();
    observer_observable.addListener(new InvalidationListener() {
      public void invalidated(Observable ov) {
        System.out.println("The new value is " + 
         observer_observable.doubleValue());
      }
    });

    observer_observable.set(7.7);
  }
}
