/* CST8221-JAP: HA 03, Example: JavaFX GridPane
   File name: BorderLayoutDemoFX.java
*/

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * This class demonstrates how to use grid layout (GridPane) in JavaFX.
 * GridPane respects the preferred sizes of the components.
 * @version 1.18.1
 * @author Svillen Ranev
 * @since JavaFX 2.0
 */

public class GridLayoutDemoFX extends Application {
   @Override
    public void start(Stage primaryStage) {
        //Create 5 Button controls
        Button one = new Button ("1");
        Button two = new Button ("2");
        Button three = new Button ("3");
        Button four = new Button ("4");
        Button equal = new Button ("=");
        //set the preferred size of the equal button
        //comment tis line to see what will happen
        equal.setPrefWidth(65.0);
        //Create a GridPane and set the gaps between the elements,
        //the padding (margins)and the positioning of the elements
        GridPane root = new GridPane();
        root.setVgap(5);
        root.setHgap(5);
        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);
        
        // Using static methods for setting node constraints
        // set the location of the controls inside the grid - column, row
        GridPane.setConstraints(one, 0, 0);
        GridPane.setConstraints(two, 1, 0);
        GridPane.setConstraints(three, 0, 1);
        GridPane.setConstraints(four, 1, 1);
        //GridPane.setConstraints(equal, 0, 3);
        
        //span the equal buuton over two colomns
       
        GridPane.setConstraints(equal, 0,2, 2, 1);
       /* 
        Add all controls to the GridPane
       */
        root.getChildren().addAll(one, two, three, 
                    four,equal);
            
        // Set the Scene and show the GUI
        Scene scene = new Scene(root,300,300);
        primaryStage.setTitle("JavaFX GridPane Example");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    /** 
     * The main method.
     * @param args not used
     */
     public static void main(String[] args) {
        launch(args);
    }
}
