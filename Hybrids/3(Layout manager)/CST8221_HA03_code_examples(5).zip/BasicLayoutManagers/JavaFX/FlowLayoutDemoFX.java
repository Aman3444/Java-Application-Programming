/* CST8221-JAP: HA 03, Example: JavaFX GridPane
   File name: FlowLayoutDemoFX.java
*/

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

/**
 * This class demonstrates how to use grid layout (GridPane) in JavaFX.
 * FlowPane respects the preferred sizes of the components.
 * @version 1.18.1
 * @author Svillen Ranev
 * @since JavaFX 2.0
 */
public class FlowLayoutDemoFX extends Application {
    
    @Override
    public void start(Stage primaryStage) {
         
         //Create 3 Button controls
        Button one = new Button ("Button 1");
       // one.setPrefWidth(200);
        Button two = new Button ("Button 1");
        Button three = new Button ("Button 3");
        //Create a FlowPane and set the gaps between the elements,
        //the alignment of the elements and the wrapping length
        FlowPane root = new FlowPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(5);
        root.setPrefWrapLength(400); // preferred width = 300
        //Add the elements to the pane
        root.getChildren().add(one);
        root.getChildren().add(two);
        root.getChildren().add(three);
        
        // // Set the Scene and show the GUI
        Scene scene = new Scene(root);
        primaryStage.setTitle("JavaFX FlowPane Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /** 
     * The main method.
     * @param args not used
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
