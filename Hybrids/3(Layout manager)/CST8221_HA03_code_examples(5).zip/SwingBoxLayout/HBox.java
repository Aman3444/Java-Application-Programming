/* CST8221-JAP: HA#03, Example: Swing HBox
   File name: HBox.java
*/
import java.awt.*;
import javax.swing.*;
/**
 A quick test of the BoxLayout manager using the Box utility class.
*/
public class HBox extends JFrame {

  
	private static final long serialVersionUID = 6483680529739015493L;

 public HBox() {
    super("Horizontal Box Test Frame");
    setSize(400, 100);
    JPanel box = new JPanel();

    // Use BoxLayout.Y_AXIS below if you want a vertical box
    box.setLayout(new BoxLayout(box, BoxLayout.LINE_AXIS)); 
    for (int i = 0; i < 3; i++) {
      JButton b = new JButton("B" + i);
      box.add(b);
    }
    JButton b = new JButton("Long B" + 4);
    box.add(b);
    setContentPane(box);
   //to center the box
   // JPanel cbox = new JPanel();
   // cbox.add(box);
   // setContentPane(cbox);
    
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setVisible(true);
  }

  public static void main(String args[]) {
    // Make all components to configured by the event dispatch thread.
     // This is the thread that passes user provoked events such as mouse clicks to 
     // the GUI components which have registered listeners for the events.
     // The following code fragment forces the statements in the run() method to be executed in the
     // event dispatch thread. 
     EventQueue.invokeLater(new Runnable()
         {
            public void run()
            {
               new HBox();
            }
         });
    
  }
}
