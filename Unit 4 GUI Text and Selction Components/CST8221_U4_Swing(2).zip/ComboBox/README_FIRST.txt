In Eclipse copy the resources folder into the bin folder of the project
In NetBeans copy the resources folder into the src folder of the project