In Eclipse copy the images folder into the bin folder of the project
In NetBeans copy the images folder into the src folder of the project