/**CST8221 - JAP, Unit 5
 * ToolBarButtonTestFX.java
 * Author: Sv. Ranev
 * Version: 1.18.1
 * Demonstrates how to build an application 
 * menu and toolbar using JavaFX 8
 * Also illustrates how to implement a "floatable" behavior in JavaFX
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Separator;
import javafx.scene.control.*;

public class ToolBarButtonTestFXM extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        //create panes to place the menu and the toolbar
        //a Vbox can be used to hold the menu and the toolbar
        // pane for menu
        BorderPane borderPaneMenu = new BorderPane();
        // pane for toolbar 
        BorderPane borderPaneTool = new BorderPane();
        Scene scene = new Scene(borderPaneMenu, 500, 500);
         MenuBar menuBar = new MenuBar();
         Menu menu = new Menu("_File");
         
        menuBar.getMenus().add(menu);
        final ToolBar toolBar = new ToolBar();
//      //toolBar.setOrientation(Orientation.VERTICAL);
        Button button1 = new Button("Button 1");
        Separator sep = new Separator(Orientation.VERTICAL);
        Button button2 = new Button("Button 2");
        Button button3 = new Button("Button 3");

       toolBar.getItems().addAll(button1,sep, button2, button3);
       toolBar.setOnMouseDragged((MouseEvent)-> {borderPaneTool.setTop(null);toolBar.setOrientation(Orientation.VERTICAL);borderPaneMenu.setLeft(toolBar);});
       borderPaneTool.setTop(toolBar);
       borderPaneMenu.setTop(menuBar);
       borderPaneMenu.setCenter(borderPaneTool);
       borderPaneMenu.setAlignment(toolBar,Pos.TOP_CENTER);
       stage.setScene(scene);
       stage.show();
    }
    /**
     * Launch application
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}