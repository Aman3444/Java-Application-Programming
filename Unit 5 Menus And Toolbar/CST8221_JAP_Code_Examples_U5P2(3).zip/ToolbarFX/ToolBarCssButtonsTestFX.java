/**CST8221 - JAP, Unit 5
 * ToolBarCssButtonsTestFX.java
 * Author: Sv. Ranev
 * Version: 1.18.1
 * Demonstrates how to build an application toolbar
 * with equal in size buttons using JavaFX 8
 * 
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.beans.*;

public class ToolBarCssButtonsTestFX extends Application {
@Override
  public void start(final Stage stage) throws Exception {
    /* Assume these are your toolbar elements */
    BorderPane borderPane = new BorderPane(); 
    Scene scene = new Scene(borderPane, 480, 500);
    
    final Button[] buttons = new Button[]{
            new Button("Button"),
            new Button("Double Button"),
            new Button("Double Double Button")
    };

    /* Make buttons rectangular using css */
    for (Button b : buttons)
        b.setStyle("-fx-background-radius: 0");

    /* Set the pref width of all your buttons to the maximum of the pref width of the larget one */
    /* The listener will be called when the GUI is dispalyed */
    final InvalidationListener listener = new InvalidationListener() {
        public void invalidated(final Observable observable) {
            double size = 0;
            for (Button b : buttons) {
                size = Math.max(size, b.prefWidth(Integer.MAX_VALUE));
             }

            for (Button b : buttons) {
                b.setPrefWidth(size);             
                b.setPrefHeight(40);
             }            
        }
    };
 //   register the listener with the width property of the buttons
   for (Button b : buttons)
      b.widthProperty().addListener(listener);

    final ToolBar toolbar = new ToolBar();
    toolbar.getItems().addAll(buttons);
    borderPane.setTop(toolbar);
    stage.setScene(scene);
    stage.setWidth(400);
    stage.setHeight(200);
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }
}