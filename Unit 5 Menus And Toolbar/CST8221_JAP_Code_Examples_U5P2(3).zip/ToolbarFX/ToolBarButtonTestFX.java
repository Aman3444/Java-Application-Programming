/**CST8221 - JAP, Unit 5
 * ToolBarButtonTestFX.java
 * Author: Sv. Ranev
 * Version: 1.18.1
 * Demonstrates how to build an application toolbar using JavaFX 8
 * 
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ToolBarButtonTestFX extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 500, 500);

        ToolBar toolBar = new ToolBar();

        Button button1 = new Button("Button 1");
        Button button2 = new Button("Button 2");
        Button button3 = new Button("Button 3");

        toolBar.getItems().addAll(button1, button2, button3);

        borderPane.setTop(toolBar);

        stage.setScene(scene);
        stage.show();
    }
    /**
     * Launch application
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}