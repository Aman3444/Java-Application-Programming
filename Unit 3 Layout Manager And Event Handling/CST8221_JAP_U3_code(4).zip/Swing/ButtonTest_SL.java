/* CST8221 - JAP - ButtonTest_SL.java
 * This application demonstrates how to single event handler in Swing
 * Author: Svillen Ranev
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Example of event handling.
 * A single listener is used - one for all button.
 * A single instance of the inner class is used as an event handler.
 */
public class ButtonTest_SL {
/** main method */
 public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable()
         {
            @Override
            public void run()
            {
               ButtonFrame_SL frame = new ButtonFrame_SL();
               frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame.setVisible(true);
            }
         });
   }
}   
/**
 * A frame with a button panel
 */
class ButtonFrame_SL extends JFrame {
   private static final long serialVersionUID = 1L;
   private final JPanel buttonPanel;
   private final JButton yellowButton;
   private final JButton blueButton;
   private final JButton redButton;
   public static final int DEFAULT_WIDTH = 600;
   public static final int DEFAULT_HEIGHT = 100;
     
   public ButtonFrame_SL(){
      setTitle("Button Test - Single Event Handler ");
      setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
      // create buttons
      yellowButton = new JButton("Yellow");
      blueButton = new JButton("Blue");
      redButton = new JButton("Red");
     
     // set action commands 
      yellowButton.setActionCommand("Y");
      blueButton.setActionCommand("B");
      redButton.setActionCommand("R");
      
      buttonPanel = new JPanel();

      // add buttons to panel
      buttonPanel.add(yellowButton);
      buttonPanel.add(blueButton);
      buttonPanel.add(redButton);

      // add panel to frame
      add(buttonPanel);

      // create a single listener
      ColorAction singleButtonsListener = new ColorAction();
      

      // register listeners - associate actions with buttons
      yellowButton.addActionListener(singleButtonsListener);
      blueButton.addActionListener(singleButtonsListener);
      redButton.addActionListener(singleButtonsListener);
   }

   /**
    * An action listener that sets the panel background color.
    */
   private class ColorAction implements ActionListener {
      
      
      public void actionPerformed(ActionEvent event){
         String command = event.getActionCommand();
         if("Y".equals(command)){
          buttonPanel.setBackground(Color.YELLOW);
          blueButton.requestFocusInWindow();
         }else 
          if("B".equals(command)){
            buttonPanel.setBackground(Color.BLUE);
            redButton.requestFocusInWindow();
          } else {
           if(((JButton)event.getSource()).getText().equals("Red")){
            buttonPanel.setBackground(Color.RED);
            yellowButton.requestFocusInWindow();
           } 
          }
      }       
   }//end inner class
}//end class