/* CST8221 - JAP - ButtonTest_ML.java
 * This application demonstrates how to many event handlers in Swing
 * Author: Svillen Ranev
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Example of event handling.
 * Many listeners are used - one per button.
 * Many instances ot the inner class are used as event handlers.
 */
public class ButtonTest_ML {
  public static void main(String[] args)  {
      EventQueue.invokeLater(new Runnable() {
            public void run()
            {
               ButtonFrame_ML frame = new ButtonFrame_ML();
               frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame.setVisible(true);
            }
         });
   }
}   
    
/**
 * A frame with a button panel
 */
class ButtonFrame_ML extends JFrame {
   private static final long serialVersionUID = 1L;
   private final JPanel buttonPanel;
   public static final int DEFAULT_WIDTH = 600;
   public static final int DEFAULT_HEIGHT = 100;
   
   public ButtonFrame_ML() {
      setTitle("Button Test - Multiple Event Handlers");
      setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);

      // create buttons
      JButton yellowButton = new JButton("Yellow");
      JButton blueButton = new JButton("Blue");
      blueButton.setPreferredSize(yellowButton.getPreferredSize());
      JButton redButton = new JButton("Red");
      redButton.setPreferredSize(yellowButton.getPreferredSize());
      buttonPanel = new JPanel();

      // add buttons to panel
      buttonPanel.add(yellowButton);
      buttonPanel.add(blueButton);
      buttonPanel.add(redButton);

      // add panel to frame
      add(buttonPanel);

      // create button actions listeners
      ColorAction yellowAction = new ColorAction(Color.YELLOW);
      ColorAction blueAction = new ColorAction(Color.BLUE);
      ColorAction redAction = new ColorAction(Color.RED);

      // register listeners - associate actions with buttons
      yellowButton.addActionListener(yellowAction);
      blueButton.addActionListener(blueAction);
      redButton.addActionListener(redAction);
   }

   /**
    * An action listener that sets the panel's background color.
    */
   private class ColorAction implements ActionListener {
      private final Color backgroundColor;
       
      public ColorAction(Color c) {
         backgroundColor = c;
      }

      @Override
      public void actionPerformed(ActionEvent event){
         buttonPanel.setBackground(backgroundColor);
      }
   }
 
}