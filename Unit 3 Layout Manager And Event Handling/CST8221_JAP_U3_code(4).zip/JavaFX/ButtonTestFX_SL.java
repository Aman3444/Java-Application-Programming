/* CST8221 - JAP - ButtonTestFX_ML.java
 * This application demonstrates how to use a single event handler in JavaFX
 * Author: Svillen Ranev
 */
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.TilePane;

/**
 * Example of event handling.
 * A single listener is used - one for all button.
 * A single instance of the inner class is used as an event handler.
 */
public class ButtonTestFX_SL extends Application {

    private Button yellowButton;
    private Button blueButton;
    private Button redButton;
    private TilePane root;
    private Scene scene;
   
    @Override
    public void start(Stage primaryStage) {
      
        root = new TilePane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10.0);
       // root.setPadding(new Insets(50, 50, 50,100)); 
        yellowButton = new Button();
        yellowButton.setText("Yellow");
        yellowButton.setMaxWidth(Double.MAX_VALUE);
        
        blueButton = new Button();
        blueButton.setText("Blue");
        blueButton.setMaxWidth(Double.MAX_VALUE);
        
        redButton = new Button();
        redButton.setText("Red");
        redButton.setMaxWidth(Double.MAX_VALUE);
        
        /*Create a single handler*/
        ColorAction handler = new ColorAction();
        yellowButton.setOnAction(handler);
        blueButton.setOnAction(handler);
        redButton.setOnAction(handler);
              
        root.getChildren().addAll(yellowButton,blueButton,redButton);
       
        scene = new Scene(root, 600, 100);

        primaryStage.setTitle("Button Test FX - Single Event Handler");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
    /**
    * An action event handler that sets the pane background color.
    */
   private class ColorAction implements EventHandler<ActionEvent> {
         

        @Override
        public void handle(ActionEvent event) {
         Button button = (Button)event.getSource();
         String command = button.getText();
         if(null != command)
            switch (command) {
                case "Yellow":
                    root.setBackground(new Background(new BackgroundFill(Color.YELLOW, CornerRadii.EMPTY, Insets.EMPTY)));
                    blueButton.requestFocus();
                    break;
                case "Blue":
                    root.setBackground(new Background(new BackgroundFill(Color.BLUE, CornerRadii.EMPTY, Insets.EMPTY)));
                    redButton.requestFocus();
                    break;
                case "Red":
                    root.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                    yellowButton.requestFocus();
                    break;
            }
        }
     }//end inner class
   
     public static void main(String[] args) {
        launch(args);
    }
}