/* CST8221 - JAP - ButtonTestFX_ML.java
 * This application demonstrates how to use many event handlers in JavaFX
 * Author: Svillen Ranev
 */
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.TilePane;

/**
 * Example of event handling
 * Many listeners are used - one per button
 * Many anonymous inner classes are used as event handlers
 */
public class ButtonTestFX_ML extends Application {

    private Button yellowButton;
    private Button blueButton;
    private Button redButton;
    private TilePane root;
    private Scene scene;
   
    @Override
    public void start(Stage primaryStage) {
      
        root = new TilePane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10.0);
     // root.setPadding(new Insets(50, 50, 50,100)); 
        yellowButton = new Button();
        yellowButton.setText("Yellow");
        yellowButton.setMaxWidth(Double.MAX_VALUE);
        //set an event handler
        yellowButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
               root.setBackground(new Background(new BackgroundFill(Color.YELLOW, CornerRadii.EMPTY, Insets.EMPTY))); 
               blueButton.requestFocus();
            }
        });
        
        blueButton = new Button();
        blueButton.setText("Blue");
        blueButton.setMaxWidth(Double.MAX_VALUE);
        //set an event handler
        blueButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
              root.setBackground(new Background(new BackgroundFill(Color.BLUE, CornerRadii.EMPTY, Insets.EMPTY))); 
             redButton.requestFocus();
            }
        });
        
        redButton = new Button();
        redButton.setText("Red");
        redButton.setMaxWidth(Double.MAX_VALUE);
        //set an event handler
        redButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
              root.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
              yellowButton.requestFocus();
            }
        });
        
        root.getChildren().addAll(yellowButton,blueButton,redButton);
       
        scene = new Scene(root, 600, 100);

        primaryStage.setTitle("ButtonTestFX - Multiple Event Handlers");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}